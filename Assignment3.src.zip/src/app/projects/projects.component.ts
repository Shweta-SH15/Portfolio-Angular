import { Component, Input } from '@angular/core';
import { Project } from '../interfaceCP';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrl: './projects.component.css'
})
export class ProjectsComponent {
  @Input() project!:Project
}