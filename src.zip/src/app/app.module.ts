import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import {MaterialModule} from './modules/material-ui.module';
import {ReactiveFormsModule} from '@angular/forms';
import {FormsModule} from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { FirefoxComponent } from './projects/firefox/firefox.component';
import { AiPromptComponent } from './projects/ai-prompt/ai-prompt.component';
import { CasinoCrapComponent } from './projects/casino-crap/casino-crap.component';
import { CoffeeRecommendationComponent } from './projects/coffee-recommendation/coffee-recommendation.component';
import { MyWorldComponent } from './projects/my-world/my-world.component';
import { ProjectsComponent } from './projects/projects.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ContactComponent,
    AboutComponent,
    FirefoxComponent,
    AiPromptComponent,
    CasinoCrapComponent,
    CoffeeRecommendationComponent,
    MyWorldComponent,
    ProjectsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
