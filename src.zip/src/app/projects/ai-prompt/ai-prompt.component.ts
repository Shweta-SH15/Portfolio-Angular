import { Component, Input } from '@angular/core';
import { Project } from '../../classSetups';
@Component({
  selector: 'app-ai-prompt',
  templateUrl: './ai-prompt.component.html',
  styleUrl: './ai-prompt.component.css'
})
export class AiPromptComponent {
  @Input() AIPrompt : Project[]=[];
}
