import { Component, Input } from '@angular/core';
import { Project } from '../../classSetups';

@Component({
  selector: 'app-coffee-recommendation',
  templateUrl: './coffee-recommendation.component.html',
  styleUrl: './coffee-recommendation.component.css'
})
export class CoffeeRecommendationComponent {
  @Input() Coffee : Project[]=[];
}
