import { Component, Input } from '@angular/core';
import { Project } from '../../classSetups';

@Component({
  selector: 'app-my-world',
  templateUrl: './my-world.component.html',
  styleUrl: './my-world.component.css'
})
export class MyWorldComponent {
  @Input() MyWorld : Project[]=[];
}
