import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CasinoCrapComponent } from './casino-crap.component';

describe('CasinoCrapComponent', () => {
  let component: CasinoCrapComponent;
  let fixture: ComponentFixture<CasinoCrapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CasinoCrapComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CasinoCrapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
