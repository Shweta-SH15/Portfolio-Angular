import { Component, Input } from '@angular/core';
import { Project } from '../../classSetups';

@Component({
  selector: 'app-casino-crap',
  templateUrl: './casino-crap.component.html',
  styleUrl: './casino-crap.component.css'
})
export class CasinoCrapComponent {
  @Input() CasinoCrap : Project[]=[];
}
