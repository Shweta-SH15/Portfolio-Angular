import { Component, Input } from '@angular/core';
import { Project } from '../../classSetups';

@Component({
  selector: 'app-firefox',
  templateUrl: './firefox.component.html',
  styleUrl: './firefox.component.css'
})
export class FirefoxComponent {
  @Input() Firefox : Project[]=[];
}
