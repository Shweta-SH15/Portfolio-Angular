import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  @Input() instagram: string = '';
  @Input() linkedIn: string = '';
  @Input() youtube: string = '';
  contact = '+1-437-882-1527';
  email = 'patelshweta255@gmail.com';
}
