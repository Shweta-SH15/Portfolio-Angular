import { Component } from '@angular/core';
import { Personal, Contact, Project, Footer, String } from './classSetups';  

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']  
})
export class AppComponent {
  title = 'portfolioAssignment';

  personalInfo: Personal = {
    Title: 'Shweta Patel',
    SubTitle: 'Aspiring Developer',
    Moto: 'Code, Create, Conquer'
  };

  contacts: Contact[] = [
    { platform: 'Instagram', link: 'https://www.instagram.com/_shivii_04_/' },
    { platform: 'LinkedIn', link: 'https://www.linkedin.com/in/shweta-patel-742ba5308/' },
    { platform: 'YouTube', link: 'https://www.youtube.com/' }
  ];

  projects: Project[] = [
    { id: 1, title: 'Firefox Splashpage', subtitle: 'Rocking the Web', img1: 'images/firefoxsplashpage.JPG', img2: '', img3: '', img4: ''},
    { id: 2, title: 'AI Prompt Generator', subtitle: 'Effortless prompt creation', img1: 'images/AIprompt.jpeg', img2: 'images/aiprompt1.jpg', img3: '', img4: ''},
    { id: 3, title: 'Casino Crap Game', subtitle: 'Roll the Dice and Hit the Jackpot', img1: 'images/casinocrap.jpg', img2: 'images/casinocrap1.jpg', img3: '', img4: ''},
    { id: 4, title: 'Coffee Recommendation', subtitle: 'Brew Your Perfect Cup', img1: 'images/coffee.jpg', img2: 'images/coffee1.jpg', img3: '', img4: ''},
    { id: 5, title: 'My World', subtitle: 'A Journey Through Recipes, Code, and Rhythm', img1: 'images/myworld.jpg', img2: 'images/cooking.jpg', img3: 'images/listening.jpg', img4: 'images/coding.jpg'}
  ];

  technologies: Footer[]=[
      { name: "HTML" }, { name: "CSS" }, { name: "TYPESCRIPT" }, { name: "JavaScript" }, { name: "Node JS" }, { name: "Angular" }
  ];
  

  darkMode: boolean = false;
}