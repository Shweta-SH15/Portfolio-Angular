import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  @Input() name: string = '';
  role = 'Software Developer';
  motto = 'Learning to code so I can finally debug my future!';
  
  @Input() instagram: string = '';
  @Input() linkedIn: string = '';
  @Input() youtube: string = '';
  @Input() darkMode: boolean = false;
}