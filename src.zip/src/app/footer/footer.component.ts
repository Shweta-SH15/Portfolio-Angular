import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  @Input() name!: string;
  technologies = ['Angular', 'TypeScript', 'HTML', 'CSS'];
  cdate = new Date();
  @Input() darkMode: boolean = false;
}