import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
    sage =  '19';
    Line1 = 'Pursuing a diploma in Computer Programming at Sheridan College, focusing on key programming skills.';
    Line2 = 'I engage in both hands-on projects and theoretical studies to ensure a well-rounded learning experience.';
    Line3 = 'My goal is to establish a robust base in software development principles and practices.';
    Line4 = 'I\'m actively expanding my skills with a range of technologies and development tools.';
    Line5 = 'Prioritizing practical skills and problem-solving to develop effective software solutions.';
}